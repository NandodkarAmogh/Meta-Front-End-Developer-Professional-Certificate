import CalculatorComponent from "./components/calculator/CalculatorComponent";
import './App.css'


function App() {
  return (
    <div className="container">
      <CalculatorComponent />
    </div>
  );
}

export default App;
